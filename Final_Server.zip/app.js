const express = require('express');
const mongoose = require('mongoose');
const app=express();
const bodyParser=require('body-parser');
require('dotenv/config');
const cors=require('cors');
const { Pool } = require('pg');   //for postgres

//middle ware
// app.use('/posts',(req,res)=>{
//     res.send("this is middleware run whenever get posts hit.");
// });

//
app.use(cors());
app.use(bodyParser.json());  //to parse JSON
app.use(bodyParser.urlencoded({extended:true}));   //donot harm my code

//importing routes
const postsRoute=require('./routes/posts');
const userRoute=require('./routes/get');
const deleteRoute=require('./routes/delete');
const putRoute=require('./routes/put');
//routes
app.use('/posts',postsRoute);
app.use('/get',userRoute);    

app.use('/delete',deleteRoute);
app.use('/put',putRoute);



app.get('/',(req,res)=>{
    res.send('we are on home');
})


app.listen(3001);


// app.delete('/',(req,res)=>{
//     console.log("hello world to name");
// });

/////////////////implementation of classes




 

